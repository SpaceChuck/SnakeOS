# SnakeOS
An OS made in Python

Download this as a zip and run main.py

# Built-in Commands:

cd - change directory

ls - list files

quit - shutdown SnakeOS

make - make a file

makedir - make a directory

del - delete a directory or a file



# Bundled Executables:

help - show help menu

calc - calculator

examples - SnakeOS examples


https://spacechucksblog.blogspot.com/2022/01/snakeos.html
