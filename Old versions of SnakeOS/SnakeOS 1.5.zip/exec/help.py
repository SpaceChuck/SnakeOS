
print("""

Built in commands

cd - change directory
ls - list files
quit - shutdown SnakeOS
make - make a file
makedir - make a directory
del - delete a directory or a file
edit - edit a file

 """)


