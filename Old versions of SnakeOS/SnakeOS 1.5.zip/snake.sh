clear
python3 main.py
