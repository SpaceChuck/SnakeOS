# snakeos_runat 0




# snakeos_runat 0 runs the plugin at startup
# snakeos_runat 1 runs the plugin on command
# snakeos_runat 2 runs the plugin at shutdown


